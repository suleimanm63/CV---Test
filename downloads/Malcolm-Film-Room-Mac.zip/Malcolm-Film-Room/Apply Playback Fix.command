#!/bin/bash
set -eu
cd "$(dirname "$0")"
echo "First stop Film Room in its Terminal window with Control+C."
echo "Choose your ORIGINAL Film Room folder, where you imported the game."
target=$(osascript -e 'POSIX path of (choose folder with prompt "Choose your ORIGINAL Film Room folder (contains Launch Film Room.command)")')
if [ ! -f "${target}/app.py" ] || [ ! -d "${target}/filmstudy" ]; then
  echo "That folder does not contain Film Room. Run this updater again and choose the correct folder."
  read -r -p "Press Return to close. " response
  exit 1
fi
source_path=$(pwd -P)
target_path=$(cd "$target" && pwd -P)
if [ "$source_path" != "$target_path" ]; then
  backup="${target}/code-backup-$(date +%Y%m%d-%H%M%S)"
  mkdir -p "$backup"
  cp "${target}/app.py" "$backup/"
  cp -R "${target}/filmstudy" "$backup/"
  cp app.py "$target/"
  cp filmstudy/*.py "${target}/filmstudy/"
fi
echo "Playback fix installed. Your recordings, reference screenshot and possession log were not changed."
echo "Now double-click Launch Film Room.command in your ORIGINAL folder."
echo "In Possession review, click Prepare video for browser and wait for it to finish."
read -r -p "Press Return to close. " response
