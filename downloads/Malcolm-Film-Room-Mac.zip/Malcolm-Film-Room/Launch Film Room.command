#!/bin/bash
set -eu
cd "$(dirname "$0")"
echo "Starting Malcolm Film Room. First launch installs the tools it needs."
if ! command -v python3.12 >/dev/null 2>&1 || ! command -v ffmpeg >/dev/null 2>&1; then
  if ! command -v brew >/dev/null 2>&1; then
    for location in /opt/homebrew/bin/brew /usr/local/bin/brew; do
      if [ -x "$location" ]; then
        eval "$("$location" shellenv)"
        break
      fi
    done
  fi
  if ! command -v brew >/dev/null 2>&1; then
    echo "Installing Homebrew from its official installer. It may ask for your Mac password."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    if [ -x /opt/homebrew/bin/brew ]; then
      eval "$(/opt/homebrew/bin/brew shellenv)"
    else
      eval "$(/usr/local/bin/brew shellenv)"
    fi
  fi
  brew install python@3.12 ffmpeg
fi
if ! command -v python3.12 >/dev/null 2>&1; then
  export PATH="$(brew --prefix python@3.12)/bin:$PATH"
fi
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements-lock.txt
.venv/bin/python -m pip install --no-deps -e .
.venv/bin/python launchers/mac_launch.py
