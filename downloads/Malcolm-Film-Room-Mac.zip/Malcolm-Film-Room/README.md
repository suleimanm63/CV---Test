# Malcolm / Film Room

A local-first basketball film study app for Malcolm, a 6'7 SF/PF wing: **#28, white jersey, black shorts**. Import authorized local MP4 files, confirm possessions, annotate decision frames, and export a styled 1080p film study with JSON/CSV logs. Works with one game first; import all three games when available.

Original source supplied: https://www.youtube.com/live/mYXe0y4-Dzc?si=IrYzKJpRjDrsZH9P. The app stores this URL as metadata and never fetches it. Obtain your MP4 through an authorized export or download route that complies with the platform's restrictions. No downloader, circumvention, or external calls run by default.

## Mac setup

Install Homebrew first if needed, then run from the repository directory:

```bash
brew install python@3.12 ffmpeg
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-lock.txt
python -m pip install --no-deps -e .
python fixtures/make_fixture.py
python -m pytest -q
streamlit run app.py --server.address 127.0.0.1 --browser.gatherUsageStats false
```

Open the local address printed by Streamlit. FFmpeg and ffprobe must be on PATH, with the `libx264` encoder available. Python 3.12 is the tested runtime. `requirements-lock.txt` pins the tested dependency versions; for a different supported platform, `pip install -e '.[test]'` resolves the bounds in `pyproject.toml`. Mac commands are documented but have not been executed on macOS here.

For files exceeding Streamlit's upload limit (200 MB by default), enter a **local file path** in the Import tab. Originals are copied into the project folder, so allow space for the source, cached intermediates, and 1080p output. You can raise the upload limit with `--server.maxUploadSize 2048`. Use only localhost binding on your own machine; there is no multi-user authentication.

## One-game MVP workflow

1. Save Malcolm's jersey details and upload a reference screenshot in the sidebar. The screenshot is for human identification; there is no jersey OCR or automatic identity matching. The screenshots supplied in chat established reference cues; use this uploader to store a local reference copy in the app.
2. Import an authorized MP4 with a game title and original source URL. The SHA-256 indexed source copy is retained under `data/originals/`. Reimporting identical content reuses the game.
3. Watch the source in **Possession review**. Enter start/end times in source seconds and confirm Malcolm's identity and the boundaries. Label on-ball offense, off-ball offense, defense, transition offense, transition defense, or other. Record result, decision point, feedback, and human identification confidence. Repeated and overlapping clips are allowed intentionally; review duplicates before export.
4. Edit each possession. Enable a freeze frame, select its source timestamp, and add circles, arrows, dashed passing lanes, or text in the annotation table. Coordinates range from 0 to 1 across the original frame. A circle at `(0.4, 0.5)` with radius `0.07` marks that point; an arrow uses `(x, y)` and `(x2, y2)`. Preview shows the rendered 1080p frame. Letterboxing does not change source coordinates.
5. Choose normal, half, or quarter speed. Each output chapter has a 2-second card, the full possession at the chosen speed, and an optional 3-second freeze frame inserted at the selected moment. Annotations appear on the freeze frame, not as moving overlays. Text should be short enough to fit the image.
6. Export the MP4 and logs from **Export**. Output is silent, H.264, 1920×1080, 30 fps with consistent navy/teal styling, chapter cards and embedded MP4 chapter metadata. Audio preservation, narration, and music are future enhancements. Playback and freeze timing have approximately one-frame precision.

Exported files: `data/exports/malcolm-filmstudy.mp4`, `possessions.json`, and `possessions.csv`. CSV includes game, start, end, play type, result, decision point, feedback, confidence, confirmation status, freeze time, speed, and JSON-encoded annotations. JSON also includes player and game/source metadata and any coaching drafts. CSV escapes spreadsheet formulas. Possessions render in log insertion order across games.

## Staged assistance

**Stage 1 — implemented:** human-confirmed timestamps, annotations, slow motion, styled rendering and structured exports. This is the reliable MVP workflow.

**Stage 2 — experimental:** sample frames at a configured interval to propose uniform-color regions. Accept/reject candidates rapidly; accepted candidates still need manually marked possession boundaries. The displayed 25% heuristic score is an explicitly uncalibrated indicator of a color match, never a probability that Malcolm is present. White jerseys are especially ambiguous. Sampling can miss short appearances, occlusions, and all events between samples. These proposals cannot enumerate all possessions automatically.

Short template tracking starts from a human-selected crop and stops on low template similarity. It supports at most ten seconds in the API (five in the UI), reports similarity separately from identity confidence, and does not create confirmed possessions. It can lose the player during motion, scale changes, camera cuts, or occlusion, or follow a teammate. This is not a trained multi-object tracker. The synthetic fixture only tests mechanics; **no real Malcolm detection or tracking accuracy has been measured**. Actual footage and reference screenshots are still needed for evaluation.

**Stage 3 — implemented:** local coaching review prompts use explicit human observations and mark every tactical decision ambiguous. They cannot infer off-screen teammates, intent, or unseen outcomes. Draft notes require review and do not overwrite final feedback. Optional external vision can suggest notes from one selected frame, with explicit configuration and per-request consent; model output may hallucinate and must be checked against the footage. Temporal reasoning over full clips and autonomous coaching assessment are not implemented.

## Configuration and privacy

```bash
cp fixtures/sample-config.json config.local.json
export FILMSTUDY_CONFIG="$PWD/config.local.json"
streamlit run app.py --server.address 127.0.0.1 --browser.gatherUsageStats false
```

The sample seeds player settings for new projects, prefills the source URL, chooses the data directory and default sampling interval, and disables external AI. `FILMSTUDY_DATA` overrides its data directory. Existing project player settings remain authoritative. Delete or move the data directory to start a different project; never edit source files in place. `project.json` is the durable review log. Back up this file with originals and the reference image. This is a single-user app: simultaneous sessions may overwrite each other's changes.

External AI is optional. Configure `external_ai` in your own local JSON only if you intend to send selected images to a provider:

```json
{
  "data_directory": "data",
  "external_ai": {
    "enabled": true,
    "endpoint": "https://api.openai.com/v1/chat/completions",
    "model": "YOUR_VISION_CAPABLE_MODEL",
    "api_key_env": "MALCOLM_AI_API_KEY"
  }
}
```

Set that key in your process environment through your local secret manager. Never commit credentials. The dashboard displays a sharing notice and requires consent before sending one selected resized JPEG plus your human observations. It sends no source URL, original MP4, full project, or reference screenshot. Only HTTPS endpoints are accepted; redirects are rejected, TLS verification remains enabled, and provider failures do not expose response bodies or credentials. External API behavior is covered by mocked tests, not a paid live request. Cached provider responses remain local. Provider retention policies and network access are your responsibility.

## Cache and reruns

Originals are content-addressed. Color sampling is keyed by source hash, color, interval, and algorithm version; manual review decisions persist by proposal ID. Template tracks, local coaching drafts, and optional AI responses are cached by their inputs. Per-possession rendering includes source hash, every possession field, player settings, and renderer version; the final cache key includes the ordered chapter keys. Editing one possession rerenders that chapter and recombines the final output while reusing unchanged chapters. Editing only feedback still updates its chapter card. A source hash check prevents rendering a modified original under a stale identity. Frame previews are decoded on demand rather than retained as a separate cache.

`data/cache/` can be deleted to regenerate intermediates. Originals and `project.json` must be preserved. Cache directories can grow substantially; cleanup is manual. The last completed MP4 remains available after edits, with a warning to rerender. Rendering uses two encoder threads to limit resource pressure; full games are sampled, not rendered wholesale.

## Tests and fixture

```bash
python fixtures/make_fixture.py             # 4s, 640×360 synthetic MP4
python -m pytest -q
python fixtures/make_demo.py                # optional 1080p example export
```

Run the dashboard against the synthetic demo with `FILMSTUDY_DATA=data/demo streamlit run app.py --server.address 127.0.0.1 --browser.gatherUsageStats false`. It is labeled as synthetic and contains no game analysis.

The generator creates a small stationary teal rectangle on a grid; it contains no footage of Malcolm. Automated tests cover import/deduplication, timestamp validation, durable review decisions, structured exports, annotation drawing, color sampling, manually seeded template tracking, local coaching ambiguity, external AI gating/caching with a mocked provider, empty/loaded dashboard execution, and end-to-end FFmpeg rendering. The render test checks actual output dimensions and duration, decodes the entire MP4, checks chapter metadata, tests cache reuse and invalidation, and rejects unconfirmed possessions. No real-game accuracy or Mac compatibility claim follows from these tests.

Future steps after receiving footage: review a labeled sample of Malcolm appearances and absences, measure proposal precision/recall, tune color/scale thresholds, evaluate tracking across camera cuts, and only then consider a licensed local detector or embedding model. Never treat jersey recognition alone as reliable identity evidence.

## Blank game playback

If the browser player stays at 0:00, click **Prepare video for browser** in Possession review. This creates a cached, local H.264/yuv420p + AAC playback copy (up to 720p) with fast-start metadata, preserving source timing. It may take several minutes or longer for a full game. Originals remain unchanged and final renders still use the original resolution. Game playback uses a loopback-only byte-range server to avoid loading the entire recording into Streamlit memory. This is intended for use on the same Mac as the browser.

For an existing downloaded app, stop its Terminal process with Control+C, unpack the updated bundle, run **Apply Playback Fix.command**, and choose the original application folder. It backs up the prior Python code and leaves imported recordings, the reference screenshot, and possession logs unchanged. Restart the original launcher, then prepare the playable copy. Gatekeeper may require Privacy & Security → Open Anyway for the new helper. This fix is validated on synthetic files; actual playback on your Mac still needs confirmation.
