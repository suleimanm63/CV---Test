import json
import os
import tempfile
from pathlib import Path
import streamlit as st
from filmstudy.core import Project, PLAY_TYPES, validate_possession, atomic_json, digest
from filmstudy.vision import frame, candidates, track
from filmstudy.render import annotate, render
from filmstudy.coaching import suggest
from filmstudy.ai import external_suggestion

st.set_page_config(page_title='Malcolm · Film Room', page_icon='🏀', layout='wide')
st.markdown('''<style>.stApp{background:#101826}h1,h2,h3{color:#38d9c5}div[data-testid="stMetric"]{background:#1b283d;padding:14px;border-radius:12px}</style>''', unsafe_allow_html=True)
st.title('Malcolm / Film Room')
st.caption('Local film study · Human-confirmed possessions · 1080p exports')
config_path = os.environ.get('FILMSTUDY_CONFIG')
config = json.loads(Path(config_path).read_text()) if config_path else {}
project = Project(os.environ.get('FILMSTUDY_DATA', config.get('data_directory', 'data')))
if not project.path.exists() and config.get('player'):
    project.state['player'].update(config['player'])
    project.save()
with st.sidebar:
    st.header('Player reference')
    with st.form('player'):
        jersey = st.text_input('Jersey number', project.state['player']['jersey_number'])
        uniform = st.text_input('Team uniform color', project.state['player']['uniform_color'])
        position = st.text_input('Position', project.state['player']['position'])
        reference = st.file_uploader('Reference screenshot', type=['png', 'jpg', 'jpeg'])
        reference_notes = st.text_area('Reference cues', project.state['player'].get('reference_notes', ''))
        if st.form_submit_button('Save reference'):
            project.state['player'].update(jersey_number=jersey, uniform_color=uniform, position=position, reference_notes=reference_notes)
            if reference:
                from PIL import Image
                image = Image.open(reference); image.verify()
                reference.seek(0)
                image = Image.open(reference).convert('RGB')
                image.save(project.root/'reference.png')
                project.state['player']['reference'] = 'reference.png'
            project.save(); st.success('Saved locally')
    if (project.root/'reference.png').exists():
        st.image(str(project.root/'reference.png'))
    st.info('Jersey recognition is not implemented. A screenshot helps human review; it does not prove identity.')
    st.caption('Local processing by default. Source URLs are never downloaded. External AI needs configuration plus consent for each selected frame.')

imports, review, discovery, exports = st.tabs(['1 · Import', '2 · Possession review', '3 · Candidates & tracking', '4 · Export'])
with imports:
    st.subheader('Authorized local MP4 recordings')
    st.write('Start with one game. Import additional games independently; source URLs are metadata only.')
    with st.form('import'):
        uploaded = st.file_uploader('MP4 file', type=['mp4'])
        local = st.text_input('Or local MP4 path (recommended for large games)')
        title = st.text_input('Game name')
        url = st.text_input('Original source URL', config.get('source_url', 'https://www.youtube.com/live/mYXe0y4-Dzc?si=IrYzKJpRjDrsZH9P'))
        authorized = st.checkbox('I am authorized to use this recording')
        if st.form_submit_button('Import game'):
            if not authorized:
                st.error('Confirm authorization before import.')
            else:
                try:
                    if uploaded:
                        with tempfile.TemporaryDirectory() as tmp:
                            path = Path(tmp)/'upload.mp4'
                            path.write_bytes(uploaded.getbuffer())
                            project.import_game(path, title, url)
                    elif local:
                        project.import_game(Path(local).expanduser(), title, url)
                    else:
                        raise ValueError('Choose an MP4 or enter a local path')
                    st.success('Imported and indexed locally'); st.rerun()
                except (ValueError, RuntimeError, OSError) as e:
                    st.error(str(e))
    for g in project.state['games']:
        st.write(f"**{g['title']}** · {g['duration']:.1f}s · {g['width']} × {g['height']}")

if not project.state['games']:
    st.info('Import a game to begin reviewing. A synthetic fixture is available under fixtures/.')
    st.stop()
game = st.sidebar.selectbox('Active game', project.state['games'], format_func=lambda g:g['title'])

with review:
    st.subheader('Mark every relevant possession')
    st.caption('Include on-ball and off-ball offense, defense, and transition. Start/end are seconds in the original game.')
    st.video(game['path'])
    with st.form('new_possession'):
        a,b,c = st.columns(3)
        start = a.number_input('Start (s)', 0.0, game['duration'], 0.0, .25)
        end = b.number_input('End (s)', 0.0, game['duration'], min(10.0,game['duration']), .25)
        kind = c.selectbox('Play type', PLAY_TYPES)
        result = st.text_input('Result', 'unknown')
        decision = st.text_input('Decision point')
        feedback = st.text_area('Coaching feedback (visible evidence only)')
        confidence = st.slider('Human identification confidence', 0.0, 1.0, 1.0, .05)
        confirmed = st.checkbox('I confirmed Malcolm and these possession boundaries')
        if st.form_submit_button('Add possession'):
            try:
                if not confirmed:
                    raise ValueError('Confirm identity and boundaries first')
                project.add_possession(game, start=start, end=end, play_type=kind, result=result,
                                       decision_point=decision, feedback=feedback, confidence=confidence)
                st.rerun()
            except ValueError as e: st.error(str(e))
    rows = [p for p in project.state['possessions'] if p['game']==game['id']]
    if rows:
        selected = st.selectbox('Edit possession', rows, format_func=lambda p:f"{p['start']:.2f}–{p['end']:.2f}s · {p['play_type']}")
        chosen = next(p for p in rows if p['id'] == selected['id'])
        with st.form('edit'):
            a,b = st.columns(2)
            new_start = a.number_input('Updated start', 0.0, game['duration'], float(chosen['start']), .25)
            new_end = b.number_input('Updated end', 0.0, game['duration'], float(chosen['end']), .25)
            new_type = st.selectbox('Updated play type', PLAY_TYPES, index=PLAY_TYPES.index(chosen['play_type']))
            new_result = st.text_input('Updated result', chosen['result'])
            new_decision = st.text_input('Updated decision point', chosen['decision_point'])
            new_feedback = st.text_area('Updated feedback', chosen['feedback'])
            new_confidence = st.slider('Updated confidence', 0.0, 1.0, float(chosen['confidence']), .05)
            freeze_on = st.checkbox('Insert 3-second annotated freeze frame', chosen.get('freeze_at') is not None)
            freeze_at = st.number_input('Freeze timestamp (s)', 0.0, game['duration'], float(chosen['freeze_at'] if chosen.get('freeze_at') is not None else chosen['start']), .1)
            speed = st.select_slider('Playback speed', options=[.25,.5,1.0], value=chosen['slow_motion'])
            st.caption('Coordinates are 0–1 across the original frame. Circle: x/y/radius. Arrow or passing lane: x/y → x2/y2. Text: x/y/text.')
            annotations = st.data_editor(chosen['annotations'] or [{'kind':'circle','x':.5,'y':.5,'x2':.7,'y2':.5,'radius':.05,'text':''}], num_rows='dynamic',
                column_config={'kind':st.column_config.SelectboxColumn(options=['circle','arrow','passing lane','text'], required=True)}, key='annotation_editor_'+chosen['id'])
            if st.form_submit_button('Save changes & preview'):
                try:
                    updated = dict(chosen, start=new_start, end=new_end, play_type=new_type, result=new_result,
                        decision_point=new_decision, feedback=new_feedback, confidence=new_confidence,
                        freeze_at=freeze_at if freeze_on else None, slow_motion=speed, annotations=annotations)
                    validate_possession(updated, game['duration'])
                    chosen.update(updated); project.save(); st.rerun()
                except (ValueError, KeyError, TypeError) as e: st.error(str(e))
        if chosen.get('freeze_at') is not None:
            st.image(annotate(frame(game['path'], chosen['freeze_at']), chosen['annotations']), caption='Freeze-frame preview')
        if st.button('Delete this possession'):
            project.state['possessions'].remove(chosen); project.save(); st.rerun()
        st.subheader('Grounded coaching draft')
        st.caption('Stage 3: local review prompts from your observations. This is not a vision model and all decisions require human review.')
        observations = st.text_area('What is visibly happening in this selected frame/clip?')
        if st.button('Suggest coaching review prompts'):
            try:
                note = suggest(project, chosen, observations)
                chosen['coaching_draft'] = note; project.save()
            except ValueError as e: st.error(str(e))
        ai_config = config.get('external_ai', {})
        if ai_config.get('enabled'):
            st.warning('External AI is configured: one selected frame and your observations will leave this machine.')
            consent = st.checkbox('I authorize sharing this selected frame with the configured AI provider')
            if st.button('Request optional vision coaching draft'):
                try:
                    selected_frame = frame(game['path'], chosen.get('freeze_at') if chosen.get('freeze_at') is not None else chosen['start'])
                    chosen['coaching_draft'] = external_suggestion(project, selected_frame, observations, ai_config, consent)
                    project.save()
                except (ValueError, RuntimeError) as e: st.error(str(e))
        if chosen.get('coaching_draft'):
            st.warning('Ambiguous decision · human review required')
            st.write(chosen['coaching_draft']['suggested_note'])
            st.write(chosen['coaching_draft'].get('review_questions', []))

with discovery:
    st.subheader('Stage 2 · Color proposals')
    st.warning('These are regions matching a color, not detections of Malcolm. Teammates and background objects can match. No calibrated identity confidence or tracking accuracy is claimed.')
    color = st.color_picker('Sampled jersey color', '#ffffff')
    interval = st.slider('Sample every N seconds', .5, 30.0, float(config.get('sampling_interval_seconds', 5)), .5)
    key = digest([game['id'], color, interval])
    if st.button('Sample game and propose timestamps'):
        try:
            with st.spinner('Sampling local frames…'):
                st.session_state[key] = candidates(game,color,interval,project.root/'cache'/'candidates')
        except (ValueError, RuntimeError) as e: st.error(str(e))
    proposals = st.session_state.get(key, [])
    pending = [p for p in proposals if project.state['candidate_reviews'].get(p['id']) is None]
    accepted = [p for p in proposals if project.state['candidate_reviews'].get(p['id']) == 'accept']
    st.caption(f'{len(proposals)} proposals · {len(pending)} pending · {len(accepted)} accepted (still need possession boundaries)')
    if pending:
        p = st.selectbox('Review candidate', pending, format_func=lambda p:f"{p['timestamp']:.1f}s · heuristic confidence {p['confidence']:.0%}")
        image = frame(game['path'], p['timestamp'])
        from PIL import ImageDraw
        overlay = image.copy(); draw = ImageDraw.Draw(overlay)
        for x,y,w,h in p['boxes']:
            draw.rectangle((x*image.width,y*image.height,(x+w)*image.width,(y+h)*image.height), outline='#ffd166', width=3)
        st.image(overlay, caption=p['reason'])
        a,b = st.columns(2)
        for column, status in [(a,'accept'),(b,'reject')]:
            if column.button(status.title()+' candidate'):
                project.state['candidate_reviews'][p['id']] = status; project.save(); st.rerun()
    if accepted:
        st.write('Accepted timestamps:', ', '.join(f"{p['timestamp']:.1f}s" for p in accepted))
        st.caption('Use the possession review tab to mark the full sequence, including off-ball actions.')
    st.subheader('Short manually seeded tracking experiment')
    st.caption('Select a textured crop of Malcolm. Template matching stops when similarity drops; it may follow the wrong player and is not an identity system.')
    t = st.number_input('Seed timestamp', 0.0, game['duration'], 0.0, .25)
    st.image(frame(game['path'], min(t, max(0,game['duration']-.1))), caption='Seed frame; use normalized crop coordinates')
    cols = st.columns(4)
    bbox = [cols[i].number_input(label, 0.0, 1.0, default, .01) for i,(label,default) in enumerate([('Crop x',.4),('Crop y',.3),('Crop width',.1),('Crop height',.2)])]
    if st.button('Track up to 5 seconds'):
        try:
            cache_key = digest(['template-v1',game['id'],t,bbox])
            path = project.root/'cache'/'tracking'/f'{cache_key}.json'
            if path.exists(): records = json.loads(path.read_text())
            else:
                records = track(game,t,bbox); atomic_json(path,records)
            st.session_state['track_result_'+game['id']] = records
        except (ValueError, RuntimeError) as e: st.error(str(e))
    if st.session_state.get('track_result_'+game['id']):
        records = st.session_state['track_result_'+game['id']]
        st.dataframe(records)
        index = st.selectbox('Review tracked frame', range(len(records)), format_func=lambda i:f"{records[i]['timestamp']:.2f}s")
        record = records[index]
        image = frame(game['path'], record['timestamp'])
        from PIL import ImageDraw
        draw = ImageDraw.Draw(image)
        x,y,w,h = record['bbox']
        draw.rectangle((x*image.width,y*image.height,(x+w)*image.width,(y+h)*image.height), outline='#38d9c5', width=3)
        st.image(image, caption='Experimental track: verify Malcolm manually')
        st.caption('Score is template similarity, not identity confidence. Results must be reviewed.')

with exports:
    st.subheader('Final film study')
    st.caption('All confirmed possessions in log order · 1080p / 30 fps · 2-second chapter cards · optional 3-second freeze frames · silent output')
    st.dataframe([{k:p[k] for k in ['game_title','start','end','play_type','result','confidence']} for p in project.state['possessions']])
    js, csv = project.exports()
    st.download_button('Download JSON log',js,'possessions.json','application/json')
    st.download_button('Download CSV log',csv,'possessions.csv','text/csv')
    if st.button('Render confirmed film study', type='primary'):
        try:
            bar = st.progress(0)
            with st.spinner('Rendering locally with FFmpeg…'):
                path = render(project,bar.progress)
                st.session_state['rendered_video'] = str(path)
            st.success('Video and logs exported to '+str(project.root/'exports'))
        except (ValueError, RuntimeError, OSError, KeyError) as e: st.error(str(e))
    rendered = st.session_state.get('rendered_video', str(project.root/'exports'/'malcolm-filmstudy.mp4'))
    if rendered and Path(rendered).exists():
        st.warning('This is the last completed render. After editing the log, render again to update the video.')
        st.video(rendered)
        with open(rendered,'rb') as f:
            st.download_button('Download final MP4',f,'malcolm-filmstudy.mp4','video/mp4')
