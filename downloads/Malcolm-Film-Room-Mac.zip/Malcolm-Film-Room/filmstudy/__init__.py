"""Local basketball film study. Detection proposals never establish identity."""
