"""Optional OpenAI-compatible vision adapter; no external calls by default."""
import base64
import io
import json
import os
import urllib.parse
import urllib.request
from .core import atomic_json, digest


def external_suggestion(project, image, observations, config, consent=False):
    if not config.get('enabled') or not consent:
        raise ValueError('External AI requires explicit enabled configuration and frame-sharing consent')
    endpoint = config.get('endpoint', '')
    parsed = urllib.parse.urlsplit(endpoint)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError('Configure a credential-free HTTPS chat/completions endpoint')
    model = config.get('model')
    if not model or not observations.strip():
        raise ValueError('A model and visible observations are required')
    key = os.environ.get(config.get('api_key_env', 'MALCOLM_AI_API_KEY'))
    if not key:
        raise ValueError('Configured API key environment variable is missing; never put its value in project files')
    image = image.copy().convert('RGB'); image.thumbnail((1280, 720))
    buffer = io.BytesIO(); image.save(buffer, format='JPEG', quality=85)
    encoded = base64.b64encode(buffer.getvalue()).decode()
    cache_key = digest(['external-coaching-v1', endpoint, model, encoded, observations])
    cache = project.root/'cache'/'external-ai'/f'{cache_key}.json'
    if cache.exists():
        return json.loads(cache.read_text())
    payload = {'model': model, 'max_tokens': 700, 'messages': [
        {'role': 'system', 'content': 'You are a basketball film review assistant. Use only the provided single frame and explicitly attributed human observations. Do not infer identity from jersey number, off-screen players, intent, play outcome, or temporal events. Separate visible evidence from uncertain coaching questions. Mark all tactical decisions as requiring human review. Do not claim that a still image shows a full possession.'},
        {'role': 'user', 'content': [
            {'type': 'text', 'text': 'Human observations (unverified): '+observations},
            {'type': 'image_url', 'image_url': {'url': 'data:image/jpeg;base64,'+encoded}}]}]}
    request = urllib.request.Request(endpoint, json.dumps(payload).encode(),
        headers={'Authorization': 'Bearer '+key, 'Content-Type': 'application/json'}, method='POST')
    # Redirects are rejected so an API key cannot be forwarded to a new destination.
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, req, fp, code, msg, headers, newurl):
            return None
    opener = urllib.request.build_opener(NoRedirect)
    try:
        with opener.open(request, timeout=45) as response:
            result = json.loads(response.read(1_000_000))
        note = result['choices'][0]['message']['content']
        if not isinstance(note, str):
            raise ValueError('Provider did not return a text response')
    except Exception as exc:
        # Do not propagate provider responses, authorization headers, or credentials.
        raise RuntimeError('External AI request failed; check endpoint, model, credentials, and network access') from None
    output = {'source': 'external vision model', 'model': model, 'suggested_note': note,
              'ambiguous': True, 'requires_human_review': True, 'evidence': observations,
              'limitations': 'One selected frame only. Model text may contain errors; verify every observation before using it.'}
    atomic_json(cache, output)
    return output
