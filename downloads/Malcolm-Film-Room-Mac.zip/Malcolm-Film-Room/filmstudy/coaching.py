"""Grounded draft prompts, never inferred off-screen events."""
from .core import atomic_json, digest
from pathlib import Path
import json


def suggest(project, possession, visible_observations):
    """Only human-entered visible evidence supports these local suggestions."""
    observations = visible_observations.strip()
    if not observations:
        raise ValueError('Describe something visible in the selected frame/clip first')
    key = digest({'stage': 'coaching-v1', 'possession': possession, 'observations': observations})
    path = project.root/'cache'/'coaching'/f'{key}.json'
    if path.exists():
        return json.loads(path.read_text())
    result = {'source': 'local rule-based review prompts; no AI call', 'evidence': observations,
              'timestamp': possession.get('freeze_at', possession['start']),
              'suggested_note': f'At this decision point, review the visible observation: {observations}. Compare the chosen action with alternatives supported by the clip.',
              'review_questions': ['Is Malcolm correctly identified?', 'Which options and defenders are actually visible?', 'Does the full possession support this feedback?'],
              'ambiguous': True, 'requires_human_review': True,
              'limitations': 'No inference about off-screen teammates, intent, unseen passes, or coaching instructions.'}
    atomic_json(path, result)
    return result
