from __future__ import annotations
import csv
import hashlib
import io
import json
import math
import os
import subprocess
import tempfile
from pathlib import Path

PLAY_TYPES = ["on-ball offense", "off-ball offense", "defense", "transition offense", "transition defense", "other"]
SCHEMA_VERSION = 1


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, allow_nan=False).encode()).hexdigest()


def file_hash(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode="w", dir=path.parent, delete=False, encoding="utf-8") as f:
        json.dump(value, f, indent=2, allow_nan=False)
        temporary = f.name
    os.replace(temporary, path)


def run(args):
    result = subprocess.run([str(x) for x in args], capture_output=True, text=True)
    if result.returncode:
        raise RuntimeError(f"{args[0]} failed: {result.stderr[-4000:]}")
    return result


def probe(path):
    info = json.loads(run(["ffprobe", "-v", "error", "-show_format", "-show_streams", "-of", "json", path]).stdout)
    streams = [s for s in info["streams"] if s["codec_type"] == "video"]
    if not streams:
        raise ValueError("File has no video stream")
    duration = float(info["format"].get("duration", 0))
    if not math.isfinite(duration) or duration <= 0:
        raise ValueError("Video must have a positive duration")
    return {"duration": duration, "width": streams[0]["width"], "height": streams[0]["height"]}


class Project:
    def __init__(self, root="data"):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / "project.json"
        self.state = json.loads(self.path.read_text()) if self.path.exists() else {
            "schema_version": SCHEMA_VERSION,
            "player": {"name": "Malcolm", "height": "6'7", "jersey_number": "28", "uniform_color": "white jersey / black shorts", "position": "SF/PF wing", "reference_notes": "White jersey over dark undershirt, dark shorts, light purple shoes; reference screenshots supplied in chat"},
            "games": [], "possessions": [], "candidate_reviews": {}, "external_ai": {"enabled": False}}

    def save(self):
        atomic_json(self.path, self.state)

    def import_game(self, local_path, title, source_url=""):
        """Copy a provided local file; never download a source URL."""
        import shutil
        metadata = probe(local_path)
        key = file_hash(local_path)
        existing = next((g for g in self.state["games"] if g["id"] == key), None)
        if existing:
            return existing
        target = self.root / "originals" / f"{key}.mp4"
        target.parent.mkdir(exist_ok=True)
        shutil.copyfile(local_path, target)
        game = {"id": key, "title": title or Path(local_path).stem, "source_url": source_url,
                "path": str(target.resolve()), **metadata}
        self.state["games"].append(game)
        self.save()
        return game

    def add_possession(self, game, **fields):
        import uuid
        row = {"id": uuid.uuid4().hex, "game": game["id"], "game_title": game["title"],
               "start": 0, "end": 1, "play_type": "other", "result": "unknown",
               "decision_point": "", "feedback": "", "confidence": 1.0,
               "confirmed": True, "annotations": [], "freeze_at": None, "slow_motion": 1.0, **fields}
        validate_possession(row, game["duration"])
        self.state["possessions"].append(row)
        self.save()
        return row

    def exports(self):
        payload = {"schema_version": SCHEMA_VERSION, "player": self.state["player"],
                   "games": [{k: v for k, v in g.items() if k != "path"} for g in self.state["games"]],
                   "possessions": self.state["possessions"]}
        buffer = io.StringIO()
        columns = ["id", "game", "game_title", "start", "end", "play_type", "result", "decision_point", "feedback", "confidence", "confirmed", "freeze_at", "slow_motion", "annotations"]
        writer = csv.DictWriter(buffer, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        for p in self.state["possessions"]:
            row = dict(p, annotations=json.dumps(p["annotations"]))
            # Avoid spreadsheet formula injection in human-entered text.
            writer.writerow({k: ("'" + v if isinstance(v, str) and v.startswith(("=", "+", "-", "@")) else v) for k, v in row.items()})
        return json.dumps(payload, indent=2, allow_nan=False), buffer.getvalue()


def validate_possession(p, duration):
    for k in ("start", "end", "confidence", "slow_motion"):
        if not isinstance(p[k], (int, float)) or not math.isfinite(p[k]):
            raise ValueError(f"Invalid {k}")
    if not 0 <= p["start"] < p["end"] <= duration:
        raise ValueError("Possession must satisfy 0 ≤ start < end ≤ game duration")
    if not 0 <= p["confidence"] <= 1 or p["slow_motion"] not in (1.0, 0.5, 0.25):
        raise ValueError("Invalid confidence or playback speed")
    if p["play_type"] not in PLAY_TYPES:
        raise ValueError("Unknown play type")
    if p.get("freeze_at") is not None and not p["start"] <= p["freeze_at"] < p["end"]:
        raise ValueError("Freeze timestamp must fall within the possession")
    for a in p.get("annotations", []):
        if a["kind"] not in ("circle", "arrow", "passing lane", "text"):
            raise ValueError("Unknown annotation kind")
        for k in ("x", "y", "x2", "y2", "radius"):
            if k in a and (not isinstance(a[k], (int, float)) or not math.isfinite(a[k]) or not 0 <= a[k] <= 1):
                raise ValueError("Annotation coordinates must be normalized to 0–1")
