"""Browser-compatible cached copies and bounded-memory local range streaming."""
import os
import re
import secrets
import tempfile
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from .core import digest, file_hash, probe, run


def prepare(project, game):
    if file_hash(game['path']) != game['id']:
        raise ValueError('Original recording changed; reimport it first')
    directory = project.root/'cache'/'playback'
    directory.mkdir(parents=True, exist_ok=True)
    target = directory/(digest(['browser-h264-aac-720-v1',game['id']])+'.mp4')
    if target.exists():
        return target
    with tempfile.TemporaryDirectory(dir=directory) as tmp:
        output = Path(tmp)/'preview.mp4'
        run(['ffmpeg','-v','error','-y','-i',game['path'],'-map','0:v:0','-map','0:a:0?',
             '-vf',r'scale=w=min(1280\,iw):h=-2,format=yuv420p','-c:v','libx264',
             '-preset','veryfast','-crf','23','-threads','2','-c:a','aac','-b:a','128k',
             '-movflags','+faststart',output])
        info=probe(output)
        if abs(info['duration']-game['duration'])>1:
            raise RuntimeError('Prepared copy has an unexpected duration')
        os.replace(output,target)
    return target


def prepared_path(project,game):
    return project.root/'cache'/'playback'/(digest(['browser-h264-aac-720-v1',game['id']])+'.mp4')


class LocalVideoServer:
    """Loopback-only file URLs with random tokens. No arbitrary filesystem routes."""
    def __init__(self):
        self.files={}
        self.lock=threading.Lock()
        owner=self
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*args): pass
            def do_HEAD(self): self.serve(False)
            def do_GET(self): self.serve(True)
            def serve(self,body):
                with owner.lock: path=owner.files.get(self.path)
                if path is None or not path.is_file():
                    self.send_error(404); return
                size=path.stat().st_size; start=0; end=size-1; partial=False
                request_range=self.headers.get('Range')
                if request_range:
                    match=re.fullmatch(r'bytes=(\d*)-(\d*)',request_range)
                    if not match or not any(match.groups()):
                        self.send_error(416); return
                    first,last=match.groups()
                    if first:
                        start=int(first); end=min(int(last),end) if last else end
                    else:
                        start=max(0,size-int(last))
                    if start>end or start>=size:
                        self.send_response(416); self.send_header('Content-Range',f'bytes */{size}'); self.end_headers(); return
                    partial=True
                self.send_response(206 if partial else 200)
                self.send_header('Content-Type','video/mp4')
                self.send_header('Accept-Ranges','bytes')
                self.send_header('Content-Length',str(end-start+1))
                if partial: self.send_header('Content-Range',f'bytes {start}-{end}/{size}')
                self.end_headers()
                if body:
                    try:
                        with path.open('rb') as f:
                            f.seek(start); remaining=end-start+1
                            while remaining:
                                block=f.read(min(remaining,256*1024))
                                if not block: break
                                self.wfile.write(block); remaining-=len(block)
                    except (BrokenPipeError,ConnectionResetError): pass
        self.server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        self.server.daemon_threads=True
        threading.Thread(target=self.server.serve_forever,daemon=True).start()

    def url(self,path):
        path=Path(path).resolve()
        with self.lock:
            token=next((key for key,value in self.files.items() if value==path),None)
            if token is None:
                token='/'+secrets.token_urlsafe(24)+'.mp4'
                self.files[token]=path
        return f'http://127.0.0.1:{self.server.server_port}{token}'

    def close(self):
        self.server.shutdown(); self.server.server_close()
