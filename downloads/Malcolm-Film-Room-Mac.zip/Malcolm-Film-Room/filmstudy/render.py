from pathlib import Path
import json
import shutil
import tempfile
from PIL import Image, ImageDraw, ImageFont
from .core import digest, file_hash, probe, run, validate_possession
from .vision import frame

WIDTH, HEIGHT = 1920, 1080
BG = '#101826'
ACCENT = '#38d9c5'
RENDER_VERSION = '1080p-v3'


def font(size):
    for path in ('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', '/System/Library/Fonts/Supplemental/Arial.ttf'):
        if Path(path).exists():
            return ImageFont.truetype(path, size)
    return ImageFont.load_default(size=size)


def fitted(image):
    image = image.copy().convert('RGB')
    image.thumbnail((WIDTH, HEIGHT))
    canvas = Image.new('RGB', (WIDTH, HEIGHT), BG)
    canvas.paste(image, ((WIDTH-image.width)//2, (HEIGHT-image.height)//2))
    return canvas, ((WIDTH-image.width)//2, (HEIGHT-image.height)//2, image.width, image.height)


def annotate(image, annotations):
    canvas, (left, top, w, h) = fitted(image)
    draw = ImageDraw.Draw(canvas)
    for a in annotations:
        x, y = left+a.get('x', .5)*w, top+a.get('y', .5)*h
        x2, y2 = left+a.get('x2', .7)*w, top+a.get('y2', .5)*h
        kind = a['kind']
        if kind == 'circle':
            r = a.get('radius', .05)*min(w, h)
            draw.ellipse((x-r, y-r, x+r, y+r), outline=ACCENT, width=7)
        elif kind in ('arrow', 'passing lane'):
            if kind == 'passing lane':
                for i in range(0, 20, 2):
                    draw.line((x+(x2-x)*i/20, y+(y2-y)*i/20, x+(x2-x)*(i+1)/20, y+(y2-y)*(i+1)/20), fill='#ffd166', width=6)
            else:
                import math
                draw.line((x, y, x2, y2), fill=ACCENT, width=7)
                angle = math.atan2(y2-y, x2-x)
                points = [(x2, y2)] + [(x2-24*math.cos(angle+s), y2-24*math.sin(angle+s)) for s in (-.5, .5)]
                draw.polygon(points, fill=ACCENT)
        if kind == 'text' or a.get('text'):
            text = str(a.get('text', ''))[:140]
            box = draw.textbbox((x, y), text, font=font(28))
            draw.rectangle((box[0]-8, box[1]-6, box[2]+8, box[3]+6), fill=BG)
            draw.text((x, y), text, font=font(28), fill='white')
    return canvas


def card(player, row, index):
    image = Image.new('RGB', (WIDTH, HEIGHT), BG)
    d = ImageDraw.Draw(image)
    d.rectangle((120, 195, 128, 850), fill=ACCENT)
    d.text((175, 200), 'MALCOLM / FILM ROOM', font=font(36), fill=ACCENT)
    d.text((175, 300), f'{index:02d}  {row["play_type"].upper()}', font=font(60), fill='white')
    d.text((175, 410), f'{row["game_title"][:60]}  •  {row["start"]:.1f}s – {row["end"]:.1f}s', font=font(32), fill='#bac6d8')
    d.text((175, 500), f'Result: {str(row["result"])[:70]}', font=font(32), fill='white')
    import textwrap
    text = row.get('feedback') or row.get('decision_point') or 'Human-confirmed possession • Review the visible evidence'
    for i, line in enumerate(textwrap.wrap(text, 85)[:5]):
        d.text((175, 600+44*i), line, font=font(30), fill='#bac6d8')
    return image


def encode_image(image_path, output, duration):
    run(['ffmpeg', '-v', 'error', '-y', '-loop', '1', '-i', image_path, '-t', duration,
         '-vf', 'fps=30,format=yuv420p', '-an', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-threads', '2', output])


def clip(game, start, end, speed, output):
    filters = f'setpts=(PTS-STARTPTS)/{speed},scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2:color=0x101826,setsar=1,fps=30,format=yuv420p'
    run(['ffmpeg', '-v', 'error', '-y', '-ss', start, '-t', end-start, '-i', game['path'],
         '-vf', filters, '-an', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-threads', '2', output])


def render(project, progress=None):
    rows = project.state['possessions']
    if not rows or any(not p.get('confirmed') for p in rows):
        raise ValueError('Render requires at least one possession; all must be human confirmed')
    games = {g['id']: g for g in project.state['games']}
    for p in rows:
        validate_possession(p, games[p['game']]['duration'])
    cache = project.root / 'cache' / 'render'
    cache.mkdir(parents=True, exist_ok=True)
    chapters, pieces, elapsed = [], [], 0.0
    for i, p in enumerate(rows, 1):
        g = games[p['game']]
        if file_hash(g['path']) != g['id']:
            raise ValueError('Original video has changed; reimport it before rendering')
        key = digest({'version': RENDER_VERSION, 'player': project.state['player'], 'index': i, 'row': p, 'source': g['id']})
        output = cache / f'{key}.mp4'
        duration = 2 + (p['end']-p['start'])/p['slow_motion'] + (3 if p.get('freeze_at') is not None else 0)
        if not output.exists():
            with tempfile.TemporaryDirectory(dir=cache) as temporary:
                temp = Path(temporary)
                segments = []
                card(project.state['player'], p, i).save(temp/'card.png')
                encode_image(temp/'card.png', temp/'card.mp4', 2)
                segments.append(temp/'card.mp4')
                freeze = p.get('freeze_at')
                if freeze is None:
                    clip(g, p['start'], p['end'], p['slow_motion'], temp/'clip.mp4')
                    segments.append(temp/'clip.mp4')
                else:
                    if freeze > p['start']:
                        clip(g, p['start'], freeze, p['slow_motion'], temp/'before.mp4')
                        segments.append(temp/'before.mp4')
                    annotate(frame(g['path'], freeze), p['annotations']).save(temp/'freeze.png')
                    encode_image(temp/'freeze.png', temp/'freeze.mp4', 3)
                    segments.append(temp/'freeze.mp4')
                    clip(g, freeze, p['end'], p['slow_motion'], temp/'after.mp4')
                    segments.append(temp/'after.mp4')
                concat(segments, temp/'joined.mp4', temp)
                shutil.move(temp/'joined.mp4', output)
        # Actual output duration, including frame rounding, drives chapter timestamps.
        duration = probe(output)['duration']
        chapters.append((elapsed, elapsed+duration, f'{i:02d} {p["play_type"]}'))
        elapsed += duration
        pieces.append(output)
        if progress:
            progress(i/len(rows))
    final_key = digest({'version': RENDER_VERSION, 'pieces': [p.stem for p in pieces]})
    target = cache / f'final-{final_key}.mp4'
    if not target.exists():
        with tempfile.TemporaryDirectory(dir=cache) as temporary:
            temp = Path(temporary)
            concat(pieces, temp/'joined.mp4', temp)
            metadata = ';FFMETADATA1\n'
            for start, end, title in chapters:
                metadata += f'[CHAPTER]\nTIMEBASE=1/1000\nSTART={round(start*1000)}\nEND={round(end*1000)}\ntitle={title}\n'
            (temp/'chapters.txt').write_text(metadata)
            run(['ffmpeg', '-v', 'error', '-y', '-i', temp/'joined.mp4', '-i', temp/'chapters.txt', '-map_metadata', '1', '-map_chapters', '1', '-c', 'copy', '-movflags', '+faststart', temp/'final.mp4'])
            shutil.move(temp/'final.mp4', target)
    exports = project.root/'exports'
    exports.mkdir(exist_ok=True)
    shutil.copyfile(target, exports/'malcolm-filmstudy.mp4')
    js, csv = project.exports()
    (exports/'possessions.json').write_text(js)
    (exports/'possessions.csv').write_text(csv)
    return exports/'malcolm-filmstudy.mp4'


def concat(pieces, output, temp):
    # Only internally generated hash/temp names enter this manifest.
    manifest = temp/'concat.txt'
    manifest.write_text(''.join(f"file '{p.resolve()}'\n" for p in pieces))
    run(['ffmpeg', '-v', 'error', '-y', '-f', 'concat', '-safe', '0', '-i', manifest, '-c', 'copy', output])
