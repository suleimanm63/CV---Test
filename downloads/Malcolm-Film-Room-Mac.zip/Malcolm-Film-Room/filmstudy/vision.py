"""Conservative proposals and short, manually seeded template tracking."""
import cv2
import numpy as np
from PIL import Image
from .core import atomic_json, digest


def frame(path, timestamp):
    cap = cv2.VideoCapture(str(path))
    try:
        cap.set(cv2.CAP_PROP_POS_MSEC, timestamp * 1000)
        ok, bgr = cap.read()
        if not ok:
            raise ValueError(f"Cannot decode frame at {timestamp:.2f}s")
        return Image.fromarray(cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB))
    finally:
        cap.release()


def candidates(game, color_hex, interval, cache_dir):
    from pathlib import Path
    if not 0.5 <= interval <= 60:
        raise ValueError("Sampling interval must be 0.5–60 seconds")
    rgb = tuple(int(color_hex.lstrip('#')[i:i+2], 16) for i in (0, 2, 4))
    key = digest({"stage": "color-proposals-v1", "game": game["id"], "color": rgb, "interval": interval})
    cache = Path(cache_dir) / f"{key}.json"
    if cache.exists():
        import json
        return json.loads(cache.read_text())
    target = cv2.cvtColor(np.uint8([[rgb]]), cv2.COLOR_RGB2HSV)[0, 0].astype(int)
    rows = []
    for timestamp in np.arange(0, game["duration"], interval):
        image = frame(game["path"], float(timestamp))
        image.thumbnail((640, 360))
        hsv = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2HSV).astype(int)
        hue = np.abs(hsv[:, :, 0] - target[0]); hue = np.minimum(hue, 180 - hue)
        # Neutral jerseys require low saturation instead of unstable hue.
        mask = (np.abs(hsv[:, :, 2] - target[2]) < 65) & (np.abs(hsv[:, :, 1] - target[1]) < 75)
        if target[1] > 50:
            mask &= hue < 12
        mask = cv2.morphologyEx(mask.astype('uint8') * 255, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        n, _, stats, _ = cv2.connectedComponentsWithStats(mask)
        boxes = []
        h, w = mask.shape
        for x, y, bw, bh, area in stats[1:]:
            fraction = area / (w*h)
            if 0.0005 <= fraction <= 0.03 and bh >= 5:
                boxes.append([float(x/w), float(y/h), float(bw/w), float(bh/h)])
        if boxes:
            rows.append({"id": digest([key, float(timestamp)]), "timestamp": float(timestamp),
                         "confidence": 0.25, "confidence_kind": "uncalibrated color heuristic; not player identity",
                         "boxes": boxes[:12], "reason": "Uniform-color regions; may include teammates, fans, or court graphics"})
    atomic_json(cache, rows)
    return rows


def track(game, timestamp, bbox, seconds=5, step=0.25):
    """Short template continuation from a human-selected crop. Stops on low match.

    Match score is NOT identity probability. No jersey recognition is performed.
    """
    if seconds <= 0 or seconds > 10 or step < 0.1:
        raise ValueError("Track 0–10 seconds with step ≥ 0.1")
    x, y, w, h = bbox
    if min(bbox) < 0 or w <= 0 or h <= 0 or x+w > 1 or y+h > 1:
        raise ValueError("Crop must fit inside the frame")
    initial = np.array(frame(game["path"], timestamp))
    initial = cv2.cvtColor(initial, cv2.COLOR_RGB2GRAY)
    height, width = initial.shape
    x, y, w, h = int(x*width), int(y*height), int(w*width), int(h*height)
    template = initial[y:y+h, x:x+w]
    if min(template.shape) < 8 or template.std() < 2:
        raise ValueError("Crop must be at least 8 pixels and contain visual texture")
    results = [{"timestamp": timestamp, "bbox": bbox, "score": 1.0, "human_seed": True}]
    for t in np.arange(timestamp+step, min(timestamp+seconds, game["duration"]), step):
        gray = cv2.cvtColor(np.array(frame(game["path"], float(t))), cv2.COLOR_RGB2GRAY)
        margin = max(w, h)
        left, top = max(0, x-margin), max(0, y-margin)
        search = gray[top:min(height, y+h+margin), left:min(width, x+w+margin)]
        scores = cv2.matchTemplate(search, template, cv2.TM_CCOEFF_NORMED)
        _, score, _, pos = cv2.minMaxLoc(scores)
        if score < 0.7:
            break
        x, y = left+pos[0], top+pos[1]
        results.append({"timestamp": float(t), "bbox": [x/width, y/height, w/width, h/height],
                        "score": float(score), "human_seed": False, "requires_review": True})
    return results
