"""Create a clearly labeled synthetic example project and 1080p export."""
from pathlib import Path
import subprocess
import sys
from filmstudy.core import Project
from filmstudy.render import render

root = Path(__file__).resolve().parents[1]
source = root/'fixtures'/'synthetic-game.mp4'
if not source.exists():
    subprocess.run([sys.executable, str(root/'fixtures'/'make_fixture.py'), str(source)],check=True)
project = Project(root/'data'/'demo')
game = project.import_game(source,'SYNTHETIC TEST — not Malcolm footage')
if not project.state['possessions']:
    project.add_possession(game,start=.25,end=1.25,play_type='other',result='Synthetic only',
        decision_point='Annotation demonstration',feedback='Synthetic fixture — no basketball coaching assessment',
        confidence=0,freeze_at=.75,slow_motion=.5,
        annotations=[{'kind':'circle','x':.42,'y':.42,'radius':.1},
                     {'kind':'arrow','x':.5,'y':.5,'x2':.7,'y2':.5},
                     {'kind':'text','x':.08,'y':.15,'text':'SYNTHETIC / ANNOTATION DEMO'}])
print(render(project))
