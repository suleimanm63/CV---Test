"""Create a four-second synthetic clip, with a stationary colored rectangle."""
from pathlib import Path
import subprocess
import sys
output = Path(sys.argv[1] if len(sys.argv)>1 else 'fixtures/synthetic-game.mp4')
output.parent.mkdir(parents=True, exist_ok=True)
subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i',
 'color=c=0x202020:s=640x360:r=30:d=4', '-vf',
 "drawbox=x=250:y=100:w=40:h=100:color=0x38d9c5:t=fill,drawgrid=w=80:h=60:t=1:c=white@0.2",
 '-an','-c:v','libx264','-pix_fmt','yuv420p',str(output)],check=True)
print(output)
