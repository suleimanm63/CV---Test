"""Open a local demo dashboard after readiness; cloud access is not implied."""
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
import urllib.request
import webbrowser


def relocate_demo(root):
    path = root/'data'/'demo'/'project.json'
    state = json.loads(path.read_text())
    for game in state['games']:
        original = root/'data'/'demo'/'originals'/f"{game['id']}.mp4"
        if not original.is_file():
            raise FileNotFoundError('Demo original is missing from this download')
        game['path'] = str(original.resolve())
    path.write_text(json.dumps(state, indent=2))


def main():
    root = Path(__file__).resolve().parents[1]
    relocate_demo(root)
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        port = sock.getsockname()[1]
    url = f'http://127.0.0.1:{port}'
    child_env = dict(os.environ, FILMSTUDY_DATA=str(root/'data'/'demo'))
    child_env.pop('FILMSTUDY_CONFIG', None)
    process = subprocess.Popen([sys.executable, '-m', 'streamlit', 'run', 'app.py',
        '--server.address', '127.0.0.1', '--server.port', str(port),
        '--server.headless', 'true', '--browser.gatherUsageStats', 'false'], cwd=root, env=child_env)
    try:
        for _ in range(60):
            if process.poll() is not None:
                raise RuntimeError('Dashboard stopped before startup completed')
            try:
                with urllib.request.urlopen(url+'/_stcore/health', timeout=1) as response:
                    if response.status == 200:
                        break
            except OSError:
                time.sleep(.5)
        else:
            raise RuntimeError('Dashboard did not become ready')
        print(f'Film Room is ready: {url}\nKeep this window open. Close the app with Control+C.', flush=True)
        webbrowser.open(url)
        process.wait()
    except KeyboardInterrupt:
        pass
    finally:
        if process.poll() is None:
            process.terminate()
            process.wait(timeout=10)


if __name__ == '__main__':
    main()
