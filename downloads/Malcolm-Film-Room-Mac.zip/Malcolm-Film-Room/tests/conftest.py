import subprocess
import sys
from pathlib import Path
import pytest
from filmstudy.core import Project

@pytest.fixture(scope='session')
def video(tmp_path_factory):
    path = tmp_path_factory.mktemp('video')/'fixture.mp4'
    subprocess.run([sys.executable, str(Path(__file__).resolve().parents[1]/'fixtures'/'make_fixture.py'), str(path)],check=True)
    return path

@pytest.fixture
def project(tmp_path,video):
    p = Project(tmp_path/'data')
    p.import_game(video,'Synthetic Game','https://example.com/authorized')
    return p
