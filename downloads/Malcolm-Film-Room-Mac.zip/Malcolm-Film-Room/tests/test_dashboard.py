from pathlib import Path
from streamlit.testing.v1 import AppTest


def test_empty_dashboard(tmp_path,monkeypatch):
    monkeypatch.setenv('FILMSTUDY_DATA',str(tmp_path/'dashboard'))
    app=AppTest.from_file(str(Path(__file__).resolve().parents[1]/'app.py')).run(timeout=30)
    assert not app.exception
    assert app.title[0].value=='Malcolm / Film Room'
    assert any('Import a game' in info.value for info in app.info)


def test_loaded_dashboard(project,monkeypatch):
    monkeypatch.setenv('FILMSTUDY_DATA',str(project.root))
    project.add_possession(project.state['games'][0],start=.25,end=1.5,play_type='defense',freeze_at=.5,
        annotations=[{'kind':'circle','x':.4,'y':.4,'radius':.05}])
    app=AppTest.from_file(str(Path(__file__).resolve().parents[1]/'app.py')).run(timeout=30)
    assert not app.exception
    assert len(app.tabs)==4
    assert any('Download JSON' in b.label for b in app.get('download_button'))


def test_dashboard_confirms_and_edits_possession(project,monkeypatch):
    monkeypatch.setenv('FILMSTUDY_DATA',str(project.root))
    app=AppTest.from_file(str(Path(__file__).resolve().parents[1]/'app.py')).run(timeout=30)
    next(c for c in app.checkbox if c.label=='I confirmed Malcolm and these possession boundaries').check()
    next(b for b in app.button if b.label=='Add possession').click().run(timeout=30)
    assert not app.exception
    from filmstudy.core import Project
    state=Project(project.root).state
    assert len(state['possessions'])==1
    assert state['possessions'][0]['confirmed']
    next(c for c in app.checkbox if c.label=='Insert 3-second annotated freeze frame').check()
    next(b for b in app.button if b.label=='Save changes & preview').click().run(timeout=30)
    assert not app.exception
    assert Project(project.root).state['possessions'][0]['freeze_at']==0
