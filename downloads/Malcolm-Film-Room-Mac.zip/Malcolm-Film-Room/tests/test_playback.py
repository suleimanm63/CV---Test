import json
import urllib.error
import urllib.request
import pytest
from filmstudy.core import file_hash,probe,run
from filmstudy.playback import prepare,LocalVideoServer


def test_browser_copy_and_cache(project):
    game=project.state['games'][0]
    before=file_hash(game['path'])
    output=prepare(project,game)
    info=json.loads(run(['ffprobe','-v','error','-show_streams','-of','json',output]).stdout)
    video=next(s for s in info['streams'] if s['codec_type']=='video')
    assert video['codec_name']=='h264' and video['pix_fmt']=='yuv420p'
    assert abs(probe(output)['duration']-game['duration'])<.1
    modified=output.stat().st_mtime_ns
    assert prepare(project,game)==output
    assert output.stat().st_mtime_ns==modified
    assert file_hash(game['path'])==before
    run(['ffmpeg','-v','error','-i',output,'-f','null','-'])


def test_range_streaming(video):
    server=LocalVideoServer()
    try:
        url=server.url(video)
        assert server.url(video)==url
        req=urllib.request.Request(url,headers={'Range':'bytes=10-29'})
        with urllib.request.urlopen(req) as response:
            assert response.status==206
            assert response.read()==video.read_bytes()[10:30]
            assert response.headers['Accept-Ranges']=='bytes'
        with urllib.request.urlopen(urllib.request.Request(url,headers={'Range':'bytes=-12'})) as response:
            assert response.read()==video.read_bytes()[-12:]
        with pytest.raises(urllib.error.HTTPError) as error:
            urllib.request.urlopen(urllib.request.Request(url,headers={'Range':'bytes=999999999-'}))
        assert error.value.code==416
        with pytest.raises(urllib.error.HTTPError) as error:
            urllib.request.urlopen(url.rsplit('/',1)[0]+'/../../etc/passwd')
        assert error.value.code==404
    finally: server.close()
