import csv
import io
import json
import subprocess
from pathlib import Path
import pytest
from PIL import Image
from filmstudy.core import Project, validate_possession, probe
from filmstudy.vision import candidates, track, frame
from filmstudy.render import render, annotate
from filmstudy.coaching import suggest
from filmstudy.ai import external_suggestion


def possession(project,**kwargs):
    return project.add_possession(project.state['games'][0],start=.25,end=1.25,
        play_type='off-ball offense', freeze_at=.75, slow_motion=.5,
        annotations=[{'kind':'circle','x':.4,'y':.4,'radius':.07},
                     {'kind':'arrow','x':.4,'y':.4,'x2':.6,'y2':.5},
                     {'kind':'passing lane','x':.3,'y':.5,'x2':.8,'y2':.2},
                     {'kind':'text','x':.1,'y':.1,'text':'Visible spacing'}],**kwargs)


def test_import_preserves_source_and_deduplicates(project,video):
    p = Project(project.root)
    assert p.state['games'][0]['source_url']=='https://example.com/authorized'
    assert p.import_game(video,'same')['id']==p.state['games'][0]['id']
    assert len(p.state['games'])==1
    assert probe(p.state['games'][0]['path'])['duration']==4

@pytest.mark.parametrize('start,end',[(1,1),(-1,2),(0,5),(float('nan'),2)])
def test_invalid_boundaries(project,start,end):
    with pytest.raises(ValueError):
        project.add_possession(project.state['games'][0],start=start,end=end)
    assert not project.state['possessions']


def test_log_exports(project):
    row = possession(project,result='=SUM(A1)',feedback='Spacing is visible')
    js, text = project.exports()
    payload = json.loads(js)
    assert payload['possessions'][0]['play_type']=='off-ball offense'
    assert 'path' not in payload['games'][0]
    record = list(csv.DictReader(io.StringIO(text)))[0]
    assert record['result']=="'=SUM(A1)"
    assert len(json.loads(record['annotations']))==4
    assert record['decision_point']==''


def test_annotations_and_validation(project):
    row = possession(project)
    g = project.state['games'][0]
    original = frame(g['path'],.75)
    rendered = annotate(original,row['annotations'])
    assert rendered.size==(1920,1080)
    assert rendered.tobytes()!=annotate(original,[]).tobytes()
    row['annotations'][0]['x']=1.1
    with pytest.raises(ValueError): validate_possession(row,4)
    row['annotations']=[]; row['freeze_at']=2
    with pytest.raises(ValueError): validate_possession(row,4)


def test_candidates_cache_and_review(project):
    game = project.state['games'][0]
    cache = project.root/'cache'/'candidates'
    rows = candidates(game,'#38d9c5',1,cache)
    assert len(rows)==4
    assert all(row['confidence']<=.25 and 'not player identity' in row['confidence_kind'] for row in rows)
    files=list(cache.glob('*.json')); times=[f.stat().st_mtime_ns for f in files]
    assert rows==candidates(game,'#38d9c5',1,cache)
    assert times==[f.stat().st_mtime_ns for f in files]
    project.state['candidate_reviews'][rows[0]['id']]='reject'; project.save()
    assert Project(project.root).state['candidate_reviews'][rows[0]['id']]=='reject'
    assert not project.state['possessions']


def test_manually_seeded_tracker(project):
    rows=track(project.state['games'][0],0,[.38,.25,.1,.35],seconds=1)
    assert len(rows)>1
    assert rows[0]['human_seed']
    assert all(r['requires_review'] for r in rows[1:])
    with pytest.raises(ValueError): track(project.state['games'][0],0,[.9,.9,.2,.2])


def test_coaching_is_ambiguous_and_grounded(project):
    row=possession(project)
    with pytest.raises(ValueError): suggest(project,row,'')
    result=suggest(project,row,'The teal rectangle is visible')
    assert result['requires_human_review'] and result['ambiguous']
    assert result['evidence']=='The teal rectangle is visible'
    assert result==suggest(project,row,result['evidence'])


def test_external_ai_requires_config_and_consent(project):
    with pytest.raises(ValueError): external_suggestion(project,Image.new('RGB',(10,10)),'visible',{})
    with pytest.raises(ValueError): external_suggestion(project,Image.new('RGB',(10,10)),'visible',{'enabled':True})
    with pytest.raises(ValueError): external_suggestion(project,Image.new('RGB',(10,10)),'visible',{'enabled':True,'endpoint':'http://example.com'},True)


def test_external_ai_mocked_and_cached(project, monkeypatch):
    monkeypatch.setenv('MALCOLM_AI_API_KEY','test-only-key')
    calls=[]
    class Response:
        def __enter__(self): return self
        def __exit__(self,*args): pass
        def read(self,size): return json.dumps({'choices':[{'message':{'content':'Review the visible spacing; uncertain.'}}]}).encode()
    class Opener:
        def open(self,req,timeout):
            calls.append(json.loads(req.data))
            return Response()
    monkeypatch.setattr('urllib.request.build_opener',lambda *args:Opener())
    cfg={'enabled':True,'endpoint':'https://example.com/v1/chat/completions','model':'test-model'}
    image=Image.new('RGB',(100,100))
    one=external_suggestion(project,image,'Visible spacing',cfg,True)
    assert one['requires_human_review']
    assert external_suggestion(project,image,'Visible spacing',cfg,True)==one
    assert len(calls)==1
    assert calls[0]['messages'][1]['content'][1]['image_url']['url'].startswith('data:image/jpeg;base64,')


def test_render_end_to_end_cache_invalidation(project):
    row=possession(project)
    output=render(project)
    info=probe(output)
    assert (info['width'],info['height'])==(1920,1080)
    assert abs(info['duration']-7)<.15 # card 2 + slowed clip 2 + freeze 3
    data=json.loads(subprocess.run(['ffprobe','-v','error','-show_chapters','-show_streams','-of','json',str(output)],capture_output=True,text=True,check=True).stdout)
    assert len(data['chapters'])==1
    assert any(s['codec_type']=='video' for s in data['streams'])
    # Decode the entire result to prove it is a playable artifact.
    subprocess.run(['ffmpeg','-v','error','-i',str(output),'-f','null','-'],check=True)
    cached=list((project.root/'cache'/'render').glob('*.mp4'))
    times={p.name:p.stat().st_mtime_ns for p in cached}
    render(project)
    assert times=={p.name:p.stat().st_mtime_ns for p in cached}
    row['feedback']='Changed feedback'; project.save(); render(project)
    assert len(list((project.root/'cache'/'render').glob('*.mp4')))==len(cached)+2
    assert json.loads((project.root/'exports'/'possessions.json').read_text())['possessions'][0]['feedback']=='Changed feedback'
    row['confirmed']=False
    with pytest.raises(ValueError): render(project)


def test_empty_project_does_not_render(tmp_path):
    with pytest.raises(ValueError): render(Project(tmp_path))
